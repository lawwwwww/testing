<?php
	session_start();
?>
<?php
	$conn=mysqli_connect("localhost","root","","trienekendb");
	
	if($conn->connect_error)
	{
		die("Connection failed:".$conn->connect_error);
	}
	
	if(isset($_GET["action"]))
	{
		if($_GET["action"]=="delete")
		{
			echo '<script>alert("Are you sure you want to delete")</script>';
			
			$del="DELETE FROM drivertable where driverID=$_GET[id]";
			mysqli_query($conn,$del);
			
		}
		
	}
?>

<!DOCTYPE html>
<html lang="eng">
<head>
	<title>View Driver</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Cafe">
    
</head>
<header>
	<?php include'navigation.php'?>
</header>
<body>
<style>
	
	form
	{
	border-style:ridge;
	padding-left:20px;
	margin-right:20px;
	padding-bottom:20px;
	}
	
	table
	{
		table-layout:auto;
		width:100%;
		border-collapse: collapse;
	}
	
	
	table, th ,td
	{
		border: 0.5px solid black;
		padding: 10px;
		text-align: center;
	}
	
	thead
	{
		background-color:#0036bd;
		color:white;
	}
	
li{list-style-type:none;}
	
	body{
		margin-left:100px;
		margin-top:20px;
	}
	


h2{
	margin-top:30px;
}

a { color: #000000; }
a:visited { #FF0000; }
a:hover,a:active,a:focus{#0F4CC8;}
	

	</style>
	<?php if(isset($_SESSION['username'])){?>
	
<br/><br/><br/>

	
		
		
	
<form>	
	<h2>Driver</h2><br/>

	<div style="overflow-x:auto;">

	<table>
	<thead>
	<tr>
		<td><p>Driver ID</p></td>
		<td>Username</td>
		<td>Password</td>
		<td>Action</td>
	</tr>	
	</thead>
	<?php
		$sql="SELECT * FROM drivertable";
		$result=mysqli_query($conn,$sql);
		
		if(mysqli_num_rows($result)>0)
		{
			while($row=mysqli_fetch_array($result))
			{
		?>
		<tr>
		<td><?php echo $row["driverID"]?></td>
		<td><?php echo $row["username"]?></td>
		<td><?php echo $row["password"]?></td>
		<td><a href="driver.php?action=delete&id=<?php echo $row["driverID"];?>" onclick="remove()">
		<span class="text-danger">Remove |</span></a>
		
		<a href="editdriver.php?action=edit&id=<?php echo $row["driverID"];?>" onclick="edit()">
			<span class="text-danger"> Edit</span></a>
	
		</td>
		</tr>
	<?php		
			}
		}
	?>	
		</table>
		<br/>
		<button><a href="newdriver.php">Create new driver</a></button>

	 </div>   
        
 </form>  
	<?php }
	else echo 'Please Login';?>
	
</body>
</html>


<?php
$conn->close();
?>