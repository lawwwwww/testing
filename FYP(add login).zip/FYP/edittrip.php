<?php
	session_start();

	$conn=mysqli_connect("localhost","root","","trienekendb");
	
	if($conn->connect_error)
	{
		die("Connection failed:".$conn->connect_error);
	}
	
	if(isset($_GET["action"]))
	{
		if($_GET["action"]=="edit")
		{
			$_SESSION['editid']=$_GET["id"];
			
		}
	}
	$edittrip=$_SESSION['editid'];
	if(isset($_POST["submit"]))
	{
		if($_POST["cust2"]!="" && $_POST["area2"]!="" && $_POST["cr2"]!="" && $_POST["cp2"]!="" && $_POST["collecttype2"]!="" && $_POST["shipdate2"]!="" && $_POST["returndate2"]!=""  && $_POST["adminid2"]!="" && $_POST["truckid2"]!="" &&$_POST["son2"]!="" &&$_POST["addr2"]!="" && $_POST["containersize2"]!=""){
	if(isset($_POST["cust2"]))
	{
			echo $_POST["hiddentripid"];
			$cc="UPDATE triptable set cust_name='".$_POST['cust2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$cc);
	
	}
	
		if(isset($_POST["area2"]))
	{
			$aa="UPDATE triptable set areaID='".$_POST['area2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$aa);
	}
	
		if(isset($_POST["cr2"]))
		{
			$crcr="UPDATE triptable set container_retrieve='".$_POST['cr2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$crcr);
		}
		
		if(isset($_POST["cp2"]))
		{
			$cpcp="UPDATE triptable set container_placed='".$_POST['cp2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$cpcp);
		}
		
		if(isset($_POST["collecttime2"]))
		{
			$ct="UPDATE triptable set collection_time='".$_POST['collecttime2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$ct);
		}
		
		if(isset($_POST["collecttype2"]))
		{
			$cty="UPDATE triptable set collection_type='".$_POST['collecttype2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$cty);
		}
	
		if(isset($_POST["wastetype2"]))
		{
			$wt="UPDATE triptable set waste_type='".$_POST['wastetype2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$wt);
		}
	
		if(isset($_POST["customersign2"]))
		{
			$cs="UPDATE triptable set customer_sign='".$_POST['customersign2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$cs);
		}
	
		if(isset($_POST["shipdate2"]))
		{
			$sd="UPDATE triptable set ship_date='".$_POST['shipdate2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$sd);
		}
	
		if(isset($_POST["returndate2"]))
		{
			$rd="UPDATE triptable set return_date='".$_POST['returndate2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$rd);
		}
	
		if(isset($_POST["driverid2"]))
		{
			$dd="UPDATE triptable set driverID='".$_POST['driverid2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$dd);
		}
	
		if(isset($_POST["adminid2"]))	
		{
			$ad="UPDATE triptable set adminID='".$_POST['adminid2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$ad);
		}

		if(isset($_POST["assignstatus2"]))
		{
			$as="UPDATE triptable set assign_status='".$_POST['assignstatus2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$as);
		}
	
		if(isset($_POST["tripstatus2"]))
		{
			$ts="UPDATE triptable set trip_status='".$_POST['tripstatus2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$ts);
		}
	
		if(isset($_POST["img2"]))
		{
			$im="UPDATE triptable set image='".$_POST['img2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$im);
		}
	
		if(isset($_POST["instruction2"]))
		{
			$inst="UPDATE triptable set instruction='".$_POST['instruction2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$inst);
		}
	
		if(isset($_POST["truckid2"]))
		{
			$tid="UPDATE triptable set truckID='".$_POST['truckid2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$tid);
		}
	
		if(isset($_POST["son2"]))
		{
			$sos="UPDATE triptable set salesOrderNo='".$_POST['son2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$sos);
		}
	
		if(isset($_POST["addr2"]))
		{
			$adr="UPDATE triptable set address='".$_POST['addr2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$adr);
		}
	
		if(isset($_POST["containersize2"]))
		{
			$csize="UPDATE triptable set container_size='".$_POST['containersize2']."' where tripID='".$edittrip."'";
			mysqli_query($conn,$csize);
		}
	header('Location:trip.php');
	}
else{
		echo '<script>alert("Invalid input!")</script>';
	
}	
	}
	
	$qq="SELECT * FROM drivertable";
	
	$resultqq=mysqli_query($conn,$qq);
?>


<!DOCTYPE html>
<html lang="eng">
<head>
	<title>Edit Trip</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Trieneken">
    
</head>

<style>
label
{
	display:inline-block;
	width:130px;
	text-align:right;
	line-height:200%;
	font-weight:bold;
}

body{
	 margin-left: 100px;
margin-top:20px;}

form{
	border-style:ridge;
	padding-left:20px;
	margin-right:20px;
	padding-bottom:20px;
}
a { color: #000000; }
a:visited { #FF0000; }
a:hover,a:active,a:focus
{#0F4CC8;}

input[type=text],input[type=file]
{
	width:500px;
	vertical-align:top;
	line-height:200%;
	margin-left:20px;
}

select
{
	margin-left:20px;
}

.tru
{
	margin-left:20px;
	font-weight:bold;
}

</style>


<header>
	<?php include'navigation.php'?>
</header>
<body>

<a style="margin-right:10px;" href="uploadfile.php">Upload DHLS</a>
<a href="trip.php">View Trip</a>

<br/><br/><br/>

<form method="post" action="edittrip.php?action=e"><!--add action and link to trip.php-->

	<h2>Edit trip</h2>
	

<?php
	$sel="SELECT * FROM triptable WHERE tripID=$edittrip";
	$sell=mysqli_query($conn,$sel);
	
	if(mysqli_num_rows($sell)>0)
	{
		while($row=mysqli_fetch_array($sell))
		{
		?>
		<br/>
		<label>Customer Name: </label>
		<input type="text" name="cust2" value="<?php echo $row["cust_name"];?>">
		
		<br/>
		<label>Area ID: </label>
		<input type="text" name="area2" value="<?php echo $row["areaID"];?>">
		<br/>
		
		<label>Container Retrieve:</label>
		<input type="text" name="cr2" value="<?php echo $row["container_retrieve"];?>">
		<br/>
		
		<label>Container Placed:</label>
		<input type="text" name="cp2" value="<?php echo $row["container_placed"];?>">
		<br/>
		
		<label>Collection Time:</label>
		<input type="text" name="collecttime2" value="<?php echo $row["collection_time"];?>">
		<br/>
		
		<label>Collection Type:</label>
		<input type="text" name="collecttype2" value="<?php echo $row["collection_type"];?>">
		<br/>
		
		<label>Waste Type:</label>
		<input type="text" name="wastetype2" value="<?php echo $row["waste_type"];?>">
		<br/>
		
		<label>Trip ID:</label>
		<span class="tru"><?php echo $row["tripID"];?>
		</span><br/>
		
		<label>Customer Sign:</label>
		<input type="file" name="customersign2" value="<?php echo $row["customer_sign"];?>">
		<br/>
		
		<label>Ship Date:</label>
		<input type="text" name="shipdate2" value="<?php echo $row["ship_date"];?>">
		<br/>
		
		<label>Return Date:</label>
		<input type="text" name="returndate2" value="<?php echo $row["return_date"];?>">
		<br/>
		
		<label>Driver:</label>
		<select name="driverid2">
		<?php while($row1=mysqli_fetch_array($resultqq)){?>
			<option value="<?php echo $row1["driverID"];?>" 
			<?php if($row1["driverID"]==$row["driverID"])
				echo 'selected="selected"';?>><?php echo $row1["username"];?>
			</option>
		<?php }?>
		</select>
			<br/>
		
		<label>Admin ID:</label>
		<input type="text" name="adminid2" value="<?php echo $row["adminID"];?>">
		<br/>
		
		<label>Assign Status:</label>
		<input type="text" name="assignstatus2" value="<?php echo $row["assign_status"];?>">
		<br/>
		
		<label>Trip Status:</label>
		<input type="text" name="tripstatus2" value="<?php echo $row["trip_status"];?>">
		<br/>
		
		<label>Image:</label>
		<input type="file" name="img2" value="<?php echo $row["image"];?>">
		<br/>
		
		<label>Instruction:</label>
		<input type="text" name="instruction2" value="<?php echo $row["instruction"];?>">
		<br/>
		
		<label>Truck ID:</label>
		<input type="text" name="truckid2" value="<?php echo $row["truckID"];?>">
		<br/>
		
		<label>Sales Order No:</label>
		<input type="text" name="son2" value="<?php echo $row["salesOrderNo"];?>">
		<br/>
		
		<label>Address:</label>
		<input type="text" name="addr2" value="<?php echo $row["address"];?>"><br/>
		
		
		<label>Container Size:</label>
		<input type="text" name="containersize2" value="<?php echo $row["container_size"];?>"><br/><br/><br/>

		
	<input type="hidden" name="hiddentripid" value="<?php $row["tripID"];?>">
	<input type="submit" name="submit" value="Submit"/>
	<button><a href="trip.php">Back</a></button>
	</form>
		<?php
	}
	}
?>

<br/><br/>

<br/><br/><br/>


</body>
</html>
