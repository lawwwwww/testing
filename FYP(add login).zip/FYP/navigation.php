<!DOCTYPE html>
<html>
<head>
<title>Order Details</title>
<link rel="stylesheet" href="navigation.css?am={random number/string}">

</head>
<header>
<div class="navvv">
	<p id="imageee"><img  src='navi.png' alt='navigation_icon' height='50px' width='50px'></p>
	<ul id="navv">
	  <li class="vava"><a href="uploadfile.php">Manage Trip</a></li>
	  <li class="vava"><a href="roro.php">Manage Container</a></li>
	  <li class="vava"><a href="driver.php">Manage Driver</a></li>
	  <li class="vava"><a href="#">Manage Holiday</a></li>
	  <li class="vava"><a href="truck.php">Manage Truck</a></li>
	  <li class="tata"><a href="#">Log Out?</a></li>
	  
	  
	</ul>
	</div>
</header>
<body>

</body>
</html>
