<?php
	session_start();

	$conn=mysqli_connect("localhost","root","","trienekendb");
	
	if($conn->connect_error)
	{
		die("Connection failed:".$conn->connect_error);
	}
	
	if(isset($_GET["action"]))
	{
		if($_GET["action"]=="edit")
		{
			$_SESSION['editroro']=$_GET["id"];
			$editroro=$_SESSION['editroro'];
		}
	}
	
	$editroro=$_SESSION['editroro'];
	if(isset($_POST["submit"]))
	{
		if($_POST["grp2"]!="" && $_POST["size2"]!="" && $_POST["pid"]!="" && $_POST["qrcode2"]!="" && $_POST["inhouse2"]!="" && $_POST["withcustomer2"]!="" && $_POST["lost2"]!="" && $_POST["longitude2"]!="" && $_POST["latitude2"]!="" && $_POST["status2"]!="" && $_POST["dayheld2"]!=""){
			if(isset($_POST["grp2"]))
	{
			$cc="UPDATE rorotable set rorogroup='".$_POST['grp2']."' where serialNo='".$editroro."'";
			mysqli_query($conn,$cc);
	
	}
	
		if(isset($_POST["size2"]))
	{
			$aa="UPDATE rorotable set size='".$_POST['size2']."' where serialNo='".$editroro."'";
			mysqli_query($conn,$aa);
	}
	
		if(isset($_POST["pid"]))
		{
			$crcr="UPDATE rorotable set productID='".$_POST['pid']."' where serialNo='".$editroro."'";
			mysqli_query($conn,$crcr);
		}
		
		if(isset($_POST["qrcode2"]))
		{
		$qcqc="UPDATE rorotable set qrcode='".$_POST['qrcode2']."' where serialNo='".$editroro."'";
			mysqli_query($conn,$qcqc);
			}
		
		if(isset($_POST["inhouse2"]))
		{
			$ct="UPDATE rorotable set in_house='".$_POST['inhouse2']."' where serialNo='".$editroro."'";
			mysqli_query($conn,$ct);
		}
		
		if(isset($_POST["withcustomer2"]))
		{
			$cty="UPDATE rorotable set with_customer='".$_POST['withcustomer2']."' where serialNo='".$editroro."'";
			mysqli_query($conn,$cty);
		}
	
		if(isset($_POST["lost2"]))
		{
			$wt="UPDATE rorotable set lost='".$_POST['lost2']."' where serialNo='".$editroro."'";
			mysqli_query($conn,$wt);
		}
	
		if(isset($_POST["longitude2"]))
		{
			$cs="UPDATE rorotable set longitude='".$_POST['longitude2']."' where serialNo='".$editroro."'";
			mysqli_query($conn,$cs);
		}
	
		if(isset($_POST["latitude2"]))
		{
			$sd="UPDATE rorotable set latitude='".$_POST['latitude2']."' where serialNo='".$editroro."'";
			mysqli_query($conn,$sd);
		}
	
		if(isset($_POST["status2"]))
		{
			$rd="UPDATE rorotable set status='".$_POST['status2']."' where serialNo='".$editroro."'";
			mysqli_query($conn,$rd);
		}
	
		if(isset($_POST["dayheld2"]))
		{
			$dd="UPDATE rorotable set day_held='".$_POST['dayheld2']."' where serialNo='".$editroro."'";
			mysqli_query($conn,$dd);
		}

		header('Location:roro.php');
	}
	else
	{
			echo '<script>alert("Invalid input!")</script>';
	
	}
	}

?>


<!DOCTYPE html>
<html lang="eng">
<head>
	<title>Edit Trip</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Trieneken">
    
</head>

<style>
label
{
	display:inline-block;
	width:130px;
	text-align:right;
	line-height:200%;
	font-weight:bold;
}

body{
	 margin-left: 100px;
margin-top:20px;}

form{
	border-style:ridge;
	padding-left:20px;
	margin-right:20px;
	padding-bottom:20px;
}
a { color: #000000; }
a:visited { #FF0000; }
a:hover,a:active,a:focus
{#0F4CC8;}

input[type=text],input[type=file]
{
	width:500px;
	vertical-align:top;
	line-height:200%;
	margin-left:20px;
}

.tru
{
	margin-left:20px;
	font-weight:bold;
}

</style>


<header>
	<?php include'navigation.php'?>
</header>
<body>

<br/><br/><br/>

<form method="post" action="editroro.php?action=e"><!--add action and link to trip.php-->

	<h2>Edit Roro</h2>
	

<?php
	$sel="SELECT * FROM rorotable WHERE serialNo='$editroro'";
	$sell=mysqli_query($conn,$sel);
	
	if(mysqli_num_rows($sell)>0)
	{
		while($row=mysqli_fetch_array($sell))
		{
		?>
		<br/>
		<label>Roro Group: </label>
		<input type="text" name="grp2" value="<?php echo $row["rorogroup"];?>">
		
		<br/>
		<label>Size </label>
		<input type="text" name="size2" value="<?php echo $row["size"];?>">
		<br/>
		
		<label>Serial No.:</label>
		<span class="tru"><?php echo $row["serialNo"];?>
		</span>
		<br/>
		
		<label>Product ID:</label>
		<input type="text" name="pid" value="<?php echo $row["productID"];?>">
		<br/>
		
		<label>QR code:</label>
		<input type="text" name="qrcode2" value="<?php echo $row["qrcode"];?>">
		<br/>
		
		<label>In House:</label>
		<input type="text" name="inhouse2" value="<?php echo $row["in_house"];?>">
		<br/>
		
		<label>With Customer:</label>
		<input type="text" name="withcustomer2" value="<?php echo $row["with_customer"];?>">
		<br/>
		
		<label>Lost:</label>
		<input type="text" name="lost2" value="<?php echo $row["lost"];?>">
		<br/>
		
		<label>Longitude:</label>
		<input type="text" name="longitude2" value="<?php echo $row["longitude"];?>">
		<br/>
		
		<label>Latitude:</label>
		<input type="text" name="latitude2" value="<?php echo $row["latitude"];?>">
		<br/>
		
		<label>Status:</label>
		<input type="text" name="status2" value="<?php echo $row["status"];?>">
		<br/>
		
		<label>Day held</label>
		<input type="text" name="dayheld2" value="<?php echo $row["day_held"];?>">
		<br/><br/>
	
	
	<input type="submit" name="submit" value="Submit"/>
	<button><a href="roro.php">Back</a></button>
	</form>
		<?php
	}
	}
?>

<br/><br/>

<br/><br/><br/>


</body>
</html>
