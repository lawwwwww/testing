<?php
	session_start();

	$conn=mysqli_connect("localhost","root","","trienekendb");
	
	if($conn->connect_error)
	{
		die("Connection failed:".$conn->connect_error);
	}
	
	if(isset($_GET["action"]))
	{
		if($_GET["action"]=="edit")
		{
			$_SESSION['edittruck']=$_GET["id"];
			$edittruck=$_SESSION['edittruck'];
		}
	}
	
	$edittruck=$_SESSION['edittruck'];

	if(isset($_POST["submit"]))
	{
		if($_POST["tru"]!="" &&$_POST["sta"]!="" )
		{
			if(isset($_POST["tru"]))
	{
			$cc="UPDATE trucktable set truckID='".$_POST['tru']."' where truckID='".$edittruck."'";
			mysqli_query($conn,$cc);
	
	}
	
		if(isset($_POST["sta"]))
	{
			$aa="UPDATE trucktable set status='".$_POST['sta']."' where truckID='".$edittruck."'";
			mysqli_query($conn,$aa);
	}
	
		header('Location:truck.php');
	}
	else
	{
		echo '<script>alert("Invalid input!")</script>';
			
	}
	}

?>


<!DOCTYPE html>
<html lang="eng">
<head>
	<title>Edit Truck</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Trieneken">
    
</head>

<style>
label
{
	display:inline-block;
	width:130px;
	text-align:right;
	line-height:200%;
	font-weight:bold;
}

body{
	 margin-left: 100px;
margin-top:20px;}

form{
	border-style:ridge;
	padding-left:20px;
	margin-right:20px;
	padding-bottom:20px;
}
a { color: #000000; }
a:visited { #FF0000; }
a:hover,a:active,a:focus
{#0F4CC8;}

input[type=text],input[type=file]
{
	width:500px;
	vertical-align:top;
	line-height:200%;
	margin-left:20px;
}

.tru
{
	margin-left:20px;
	font-weight:bold;
}

</style>


<header>
	<?php include'navigation.php'?>
</header>
<body>

<br/><br/><br/>

<form method="post" action="edittruck.php?action=e"><!--add action and link to trip.php-->

	<h2>Edit Truck</h2>
	

<?php
	$sel="SELECT * FROM trucktable WHERE truckID=$edittruck";
	$sell=mysqli_query($conn,$sel);
	
	if(mysqli_num_rows($sell)>0)
	{
		while($row=mysqli_fetch_array($sell))
		{
		?>
		<br/>
		<label>Truck ID: </label>
		<input type="text" name="tru" value="<?php echo $row["truckID"];?>">
		
		<br/>
		<label>Status: </label>
		<input type="text" name="sta" value="<?php echo $row["status"];?>">
		<br/><br/>
	
	
	<input type="submit" name="submit" value="Submit"/>
	<button><a href="truck.php">Back</a></button>
	</form>
		<?php
	}
	}
?>

<br/><br/>

<br/><br/><br/>


</body>
</html>
