<?php
	session_start();

	$conn=mysqli_connect("localhost","root","","trienekendb");
	
	if($conn->connect_error)
	{
		die("Connection failed:".$conn->connect_error);
	}
	
	if(isset($_POST["submit"]))
	{
		$ins="INSERT INTO drivertable (username,password)VALUES('$_POST[uname]','$_POST[pw]')";
		
		mysqli_query($conn,$ins);
		
		header('Location: driver.php');
	}
	
	
	
?>


<!DOCTYPE html>
<html lang="eng">
<head>
	<title>Create Driver</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Trieneken">
    
</head>

<style>
label
{
	display:inline-block;
	width:130px;
	text-align:right;
	line-height:200%;
	font-weight:bold;
}

body{
	 margin-left: 100px;
margin-top:20px;}

form{
	border-style:ridge;
	padding-left:20px;
	margin-right:20px;
	padding-bottom:20px;
}
a { color: #000000; }
a:visited { #FF0000; }
a:hover,a:active,a:focus
{#0F4CC8;}

input[type=text],input[type=file]
{
	width:500px;
	vertical-align:top;
	line-height:200%;
	margin-left:20px;
}

.tru
{
	margin-left:20px;
	font-weight:bold;
}

</style>


<header>
	<?php include'navigation.php'?>
</header>
<body>

<br/><br/><br/>

<form method="post" action="newdriver.php?action=add"><!--add action and link to trip.php-->

	<h2>Create Driver</h2>
	
	<br/>
		
		<label>Username </label>
		<input type="text" name="uname">
		<br/>
		
		<label>Password:</label>
		<input type="text" name="pw" >
		<br/><br/>
	
	
	<input type="submit" name="submit" value="Submit"/>
	<button><a href="driver.php">Back</a></button>
	</form>


<br/><br/>

<br/><br/><br/>


</body>
</html>
