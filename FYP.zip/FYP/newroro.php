<?php
	session_start();

	$conn=mysqli_connect("localhost","root","","trienekendb");
	
	if($conn->connect_error)
	{
		die("Connection failed:".$conn->connect_error);
	}
	
	if(isset($_POST["submit"]))
	{
		$ins="INSERT INTO rorotable (rorogroup,size,serialNo,productID,qrcode,in_house,with_customer,lost,longitude,latitude,status,day_held)VALUES('$_POST[grp2]','$_POST[size2]','$_POST[sno]','$_POST[pid]','$_POST[qrcode]','$_POST[inhouse2]','$_POST[withcustomer2]','$_POST[lost2]','$_POST[longitude2]','$_POST[latitude2]','$_POST[status2]','$_POST[dayheld2]')";
		
		mysqli_query($conn,$ins);
		
		header('Location: roro.php');
	}
	
	
	
?>


<!DOCTYPE html>
<html lang="eng">
<head>
	<title>Create Roro</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Trieneken">
    
</head>

<style>
label
{
	display:inline-block;
	width:130px;
	text-align:right;
	line-height:200%;
	font-weight:bold;
}

body{
	 margin-left: 100px;
margin-top:20px;}

form{
	border-style:ridge;
	padding-left:20px;
	margin-right:20px;
	padding-bottom:20px;
}
a { color: #000000; }
a:visited { #FF0000; }
a:hover,a:active,a:focus
{#0F4CC8;}

input[type=text],input[type=file]
{
	width:500px;
	vertical-align:top;
	line-height:200%;
	margin-left:20px;
}

.tru
{
	margin-left:20px;
	font-weight:bold;
}

</style>


<header>
	<?php include'navigation.php'?>
</header>
<body>

<br/><br/><br/>

<form method="post" action="newroro.php?action=add"><!--add action and link to trip.php-->

	<h2>Create Roro</h2>
	
	<br/>
		<label>Roro Group: </label>
		<input type="text" name="grp2">
		
		<br/>
		<label>Size </label>
		<input type="text" name="size2">
		<br/>
		
		<label>Serial No.:</label>
		<input type="text" name="sno" >
		
		<br/>
		
		<label>Product ID:</label>
		<input type="text" name="pid" >
		<br/>
		
		<label>QR code:</label>
		<input type="text" name="qrcode" >
		<br/>
		
		<label>In House:</label>
		<input type="text" name="inhouse2">
		<br/>
		
		<label>With Customer:</label>
		<input type="text" name="withcustomer2">
		<br/>
		
		<label>Lost:</label>
		<input type="text" name="lost2">
		<br/>
		
		<label>Longitude:</label>
		<input type="text" name="longitude2">
		<br/>
		
		<label>Latitude:</label>
		<input type="text" name="latitude2">
		<br/>
		
		<label>Status:</label>
		<input type="text" name="status2">
		<br/>
		
		<label>Day held</label>
		<input type="text" name="dayheld2">
		<br/><br/>
	
	
	<input type="submit" name="submit" value="Submit"/>
	<button><a href="roro.php">Back</a></button>
	</form>


<br/><br/>

<br/><br/><br/>


</body>
</html>
