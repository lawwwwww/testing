<?php
	$conn=mysqli_connect("localhost","root","","trienekendb");
	
	if($conn->connect_error)
	{
		die("Connection failed:".$conn->connect_error);
	}
	
	if(isset($_GET["action"]))
	{
		if($_GET["action"]=="delete")
		{
			echo '<script>alert("Are you sure you want to delete")</script>';
			
			$del="DELETE FROM rorotable where serialNo='$_GET[id]'";
			mysqli_query($conn,$del);
			
		}
		
	}
?>

<!DOCTYPE html>
<html lang="eng">
<head>
	<title>View Roro</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Cafe">
    
</head>
<header>
	<?php include'navigation.php'?>
</header>
<body>

<br/><br/><br/>

	<style>
	
	form
	{
	border-style:ridge;
	padding-left:20px;
	margin-right:20px;
	padding-bottom:20px;
	}
	
	table
	{
		table-layout:auto;
		width:100%;
		border-collapse: collapse;
	}
	
	
	table, th ,td
	{
		border: 0.5px solid black;
		padding: 10px;
		text-align: center;
	}
	
	thead
	{
		background-color:#0036bd;
		color:white;
	}
	
li{list-style-type:none;}
	
	body{
		margin-left:100px;
		margin-top:20px;
	}
	


h2{
	margin-top:30px;
}

a { color: #000000; }
a:visited { #FF0000; }
a:hover,a:active,a:focus{#0F4CC8;}
	

	</style>
<form>	
	<h2>Roro Container</h2><br/>

	<div style="overflow-x:auto;">

	<table>
	<thead>
	<tr>
		<td><p>Roro Group</p></td>
		<td>Size</td>
		<td>Serial No.</td>
		<td>Product ID</td>
		<td>QR code</td>
		<td>In house</td>
		<td>With customer</td>
		<td>Lost</td>
		<td>Longitude</td>
		<td>Latitude</td>
		<td>Status</td>
		<td>Day held</td>
		<td>Action</td>
	</tr>	
	</thead>
	<?php
		$sql="SELECT * FROM rorotable";
		$result=mysqli_query($conn,$sql);
		
		if(mysqli_num_rows($result)>0)
		{
			while($row=mysqli_fetch_array($result))
			{
		?>
		<tr>
		<td><?php echo $row["rorogroup"]?></td>
		<td><?php echo $row["size"]?></td>
		<td><?php echo $row["serialNo"]?></td>
		<td><?php echo $row["productID"]?></td>
		<td><?php echo $row["qrcode"]?></td>
		<td><?php echo $row["in_house"]?></td>
		<td><?php echo $row["with_customer"]?></td>
		<td><?php echo $row["lost"]?></td>
		<td><?php echo $row["longitude"]?></td>
		<td><?php echo $row["latitude"]?></td>
		<td><?php echo $row["status"]?></td>
		<td><?php echo $row["day_held"]?></td>
		<td><a href="roro.php?action=delete&id=<?php echo $row["serialNo"];?>" onclick="remove()">
		<span class="text-danger">Remove |</span></a>
		
		<a href="editroro.php?action=edit&id=<?php echo $row["serialNo"];?>" onclick="edit()">
			<span class="text-danger"> Edit</span></a>
	
		</td>
		</tr>
	<?php		
			}
		}
	?>	
		</table>
		<br/>
		<button><a href="newroro.php">Create new roro</a></button>

	 </div>   
        
 </form>  
	
</body>
</html>


<?php
$conn->close();
?>