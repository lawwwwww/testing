<?php
$conn=mysqli_connect("localhost","root","","trienekendb");
	
	if($conn->connect_error)
	{
		die("Connection failed:".$conn->connect_error);
	}
	
$qq="SELECT * FROM drivertable";

$result=mysqli_query($conn,$qq);

?>

<!DOCTYPE html>

<html>

    <head>

        <title> PHP SELECT OPTIONS FROM DATABASE </title>

        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>

    <body>
	<select name="ss">
	<?php
	$iii=10;
	?>
	
	<?php while($row1=mysqli_fetch_array($result)){?>
		<option value="<?php echo $row1["driverID"];?>" <?php if($row1["driverID"]==$iii)echo 'selected="selected"';?>><?php echo $row1["username"];?></option>
	<?php
	}
	?>
	</select>
	
	