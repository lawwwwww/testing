<?php
	session_start();
?>
<?php
	$conn=mysqli_connect("localhost","root","","trienekendb");
	
	if($conn->connect_error)
	{
		die("Connection failed:".$conn->connect_error);
	}
	
	if(isset($_GET["action"]))
	{
		if($_GET["action"]=="delete")
		{
			echo '<script>alert("Are you sure you want to delete")</script>';
			
			$del="DELETE FROM triptable where tripID=$_GET[id]";
			mysqli_query($conn,$del);
			
		}
		
	}
?>

<!DOCTYPE html>
<html lang="eng">
<head>
	<title>View Trip</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Cafe">
    
</head>
<header>
	<?php include'navigation.php'?>
</header>
<body style="margin-left:100px;margin-top:20px;">

	<?php if(isset($_SESSION['username'])){?>
<a style="margin-right:10px;" href="uploadfile.php">Upload DHLS</a>
<a href="trip.php">View Trip</a>
<br/><br/><br/>

	<style>
	
	form
	{
	border-style:ridge;
	padding-left:20px;
	margin-right:20px;
	padding-bottom:20px;
	}
	
	table
	{
		table-layout:auto;
		width:100%;
		border-collapse: collapse;
	}
	
	
	table, th ,td
	{
		border: 0.5px solid black;
		padding: 10px;
		text-align: center;
	}
	
	thead
	{
		background-color:#0036bd;
		color:white;
	}
	
li{list-style-type:none;}
	
	body{
		margin-left:100px;
		margin-top:20px;
	}
	


h2{
	margin-top:30px;
}

a { color: #000000; }
a:visited { #FF0000; }
a:hover,a:active,a:focus{#0F4CC8;}
	

	</style>

<form>	
	<h2>Trip</h2><br/>

	<div style="overflow-x:auto;">

	<table>
	<thead>
	<tr>
		<td><p>Customer name</p></td>
		<td>Area ID</td>
		<td>Container retrieve</td>
		<td>Container placed</td>
		<td>Collection time</td>
		<td>Collection type</td>
		<td>Waste type</td>
		<td>Trip ID</td>
		<td>Customer signature</td>
		<td>Ship date</td>
		<td>Return date</td>
		<td>Driver ID</td>
		<td>Admin ID</td>
		<td>Assign status</td>
		<td>Trip status</td>
		<td>Image</td>
		<td>Instruction</td>
		<td>Truck ID</td>
		<td>Sales order no.</td>
		<td>Address</td>
		<td>Container size</td>
		<td>Action</td>
	</tr>	
	</thead>
	<?php
		$sql="SELECT * FROM triptable";
		$result=mysqli_query($conn,$sql);
		
		if(mysqli_num_rows($result)>0)
		{
			while($row=mysqli_fetch_array($result))
			{
		?>
		<tr>
		<td><?php echo $row["cust_name"]?></td>
		<td><?php echo $row["areaID"]?></td>
		<td><?php echo $row["container_retrieve"]?></td>
		<td><?php echo $row["container_placed"]?></td>
		<td><?php echo $row["collection_time"]?></td>
		<td><?php echo $row["collection_type"]?></td>
		<td><?php echo $row["waste_type"]?></td>
		<td><?php echo $row["tripID"]?></td>
		<td><?php echo $row["customer_sign"]?></td>
		<td><?php echo $row["ship_date"]?></td>
		<td><?php echo $row["return_date"]?></td>
		<td><?php echo $row["driverID"]?></td>
		<td><?php echo $row["adminID"]?></td>
		<td><?php echo $row["assign_status"]?></td>
		<td><?php echo $row["trip_status"]?></td>
		<td><?php echo $row["image"]?></td>
		<td><?php echo $row["instruction"]?></td>
		<td><?php echo $row["truckID"]?></td>
		<td><?php echo $row["salesOrderNo"]?></td>
		<td><?php echo $row["address"]?></td>
		<td><?php echo $row["container_size"]?></td>
		<td><a href="trip.php?action=delete&id=<?php echo $row["tripID"];?>" onclick="remove()">
		<span class="text-danger">Remove |</span></a>
		
		<a href="edittrip.php?action=edit&id=<?php echo $row["tripID"];?>" onclick="edit()">
			<span class="text-danger"> Edit</span></a>
		</form>
		</td>
		</tr>
	<?php		
			}
		}
	?>	
		</table>

	 </div>   
        
 </form>  
	<?php }
	else{
			echo 'Please <a href="login.php">Login</a>';
		}?> 

</body>
</html>


<?php
$conn->close();
?>