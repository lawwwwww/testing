<a href="driver.php" style="margin-right:10px;">View driver</a>	
	<a href="viewfeedback.php" style="margin-right:10px;">View Feedback</a>
	<a href="driverperform.php">View Driver Performance</a>	