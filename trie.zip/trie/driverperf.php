<?php

	include_once 'connection.php';
	if(isset($_POST['dridate'])){
		$yearofd = $_POST['dridate'];
		$startdate = date("Y-m-d",strtotime("$_POST[dridate]-01-01"));
		$enddate = date('Y-m-d', strtotime($startdate . ' +1 year'));
		$theyear = date("Y",strtotime($startdate));
		$counting = 0;
		$smallstartdate = date("Y-m-d",strtotime($startdate));
		$smallenddate = date("Y-m-d",strtotime($startdate . '+1 month'));
		
		while($counting<12){
			$extract = mysqli_query($conn,"SELECT DISTINCT driverID FROM tripdonetable WHERE invoice_date BETWEEN '$smallstartdate' AND '$smallenddate'");
			if($extract->num_rows>0){
				$array_month_result = [];
				$driver_array = [];
				while($row = $extract-> fetch_assoc()){
					$xyzz = mysqli_query($conn,"SELECT username FROM drivertable WHERE driverID = '$row[driverID]'");
					$xyz = mysqli_query($conn,"SELECT COUNT(driverID) as total FROM tripdonetable WHERE driverID = '$row[driverID]'  AND invoice_date BETWEEN '$startdate' AND '$enddate'");
					$total = mysqli_fetch_assoc($xyz);
					$name = mysqli_fetch_assoc($xyzz);
					array_push($array_month_result,$total['total']);
					array_push($driver_array,$name['username']);
					
				}
				echo '<p class="hiding" id="data'.$counting.'">';
				for($x = 0; $x < count($array_month_result); $x++){
					echo $array_month_result[$x].',';
				}
				echo '</p>';
				echo '<p class="hiding" id="driver'.$counting.'">';
				for($x = 0; $x < count($driver_array); $x++){
					echo $driver_array[$x].',';
				}
				echo '</p>';
			}else{
				echo '<p class="hiding" id="data'.$counting.'"></p>';
				echo '<p class="hiding" id="driver'.$counting.'"></p>';
			}
			$smallstartdate = date("Y-m-d",strtotime($smallstartdate.'+1 month'));
			$smallenddate = date("Y-m-d",strtotime($smallenddate . '+1 month'));
			$counting += 1;
		}
		echo '<p class="hiding" id="year">'.$theyear.'</p>';
		
	}else{
		header("Location:driverperform.php");
	}
?>
<!DOCTYPE html>
<html>
	<head>
    	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="table2.css">
		<title></title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
	</head>
	<header>
	<?php include'navigation.php'?>
</header>
	<body>
	
	

	<div class="container-fluid">
	<div class="row">
	<div class="col-md-4">
	<canvas id="myChart1"></canvas>
	</div>
	<div class="col-md-4">
	<canvas id="myChart2"></canvas>
	</div>
	<div class="col-md-4">
	<canvas id="myChart3"></canvas>
	</div>
	</div>
	
	<div class="row">
	<div class="col-md-4">
	<canvas id="myChart4"></canvas>
	</div>
	<div class="col-md-4">
	<canvas id="myChart5"></canvas>
	</div>
	<div class="col-md-4">
	<canvas id="myChart6"></canvas>
	</div>
	</div>
	
	<div class="row">
	<div class="col-md-4">
	<canvas id="myChart7"></canvas>
	</div>
	<div class="col-md-4">
	<canvas id="myChart8"></canvas>
	</div>
	<div class="col-md-4">
	<canvas id="myChart9"></canvas>
	</div>
	</div>
	
	<div class="row">
	<div class="col-md-4">
	<canvas id="myChart10"></canvas>
	</div>
	<div class="col-md-4">
	<canvas id="myChart11"></canvas>
	</div>
	<div class="col-md-4">
	<canvas id="myChart12"></canvas>
	</div>
	</div>
	
<script>
	let myChart0 = document.getElementById('myChart1').getContext('2d');
	Chart.defaults.global.defaultFontFamily='Calibri';
	Chart.defaults.global.defaultFontSize=15;
	Chart.defaults.global.defaultFontColor='green';
	var yearr = document.getElementById('year').innerHTML;
	var x1 = document.getElementById('data0').innerHTML;
	var y1 = document.getElementById('driver0').innerHTML;
	console.log(x1);
	var x1 = x1.slice(0,-1);
	var y1 = y1.slice(0,-1);
	var xx1 = x1.split(",");
	var yy1 = y1.split(",");
	console.log(x1);
	console.log(y1);
	console.log(xx1);
	console.log(yy1);
	let driverChart0 = new Chart(myChart0,{
		type:'bar',// bar, horizontalBar, pie, line, doughnut, radar, polarArea
		data:{
			labels:yy1,
			datasets:[{
				label:'Driver Name',
				data:xx1,
				backgroundColor:['green','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD'],
				borderWidth:2,
				borderColor: 'grey',
				hoverBorderWidth:3,
				hoverBorderColor: 'grey',
			}]
		},
		options:{
			title:{
				display:true,
				text:' Driver Performances' + ' January ' + yearr,
				fontSize:20
			},
			legend:{
				position:'right', // top bottom left right
				labels:{
					fontColor:'#000'
				}
			},
			layout:{
				padding:{
					left:20,
					right:20,
					bottom:0,
					top:10
				}
			},
			tooltips:{
				enabled:true
			}
		}
	});
	</script>
	<script>
	let myChart = document.getElementById('myChart2').getContext('2d');
	Chart.defaults.global.defaultFontFamily='Calibri';
	Chart.defaults.global.defaultFontSize=15;
	Chart.defaults.global.defaultFontColor='green';
	var x1 = document.getElementById('data1').innerHTML;
	var y1 = document.getElementById('driver1').innerHTML;
	console.log(x1);
	var x1 = x1.slice(0,-1);
	var y1 = y1.slice(0,-1);
	var xx1 = x1.split(",");
	var yy1 = y1.split(",");
	console.log(x1);
	console.log(y1);
	console.log(xx1);
	console.log(yy1);
	let driverChart = new Chart(myChart,{
		type:'bar',// bar, horizontalBar, pie, line, doughnut, radar, polarArea
		data:{
			labels:yy1,
			datasets:[{
				label:'Driver Name',
				data:xx1,
				backgroundColor:['green','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD'],
				borderWidth:2,
				borderColor: 'grey',
				hoverBorderWidth:3,
				hoverBorderColor: 'grey',
			}]
		},
		options:{
			title:{
				display:true,
				text:'Driver Performances February ' + yearr,
				fontSize:20
			},
			legend:{
				position:'right', // top bottom left right
				labels:{
					fontColor:'#000'
				}
			},
			layout:{
				padding:{
					left:20,
					right:20,
					bottom:0,
					top:10
				}
			},
			tooltips:{
				enabled:true
			}
		}
	});
	</script>
	<script>
	let myChart2 = document.getElementById('myChart3').getContext('2d');
	Chart.defaults.global.defaultFontFamily='Calibri';
	Chart.defaults.global.defaultFontSize=15;
	Chart.defaults.global.defaultFontColor='green';
	
	var x1 = document.getElementById('data2').innerHTML;
	var y1 = document.getElementById('driver2').innerHTML;
	console.log(x1);
	var x1 = x1.slice(0,-1);
	var y1 = y1.slice(0,-1);
	var xx1 = x1.split(",");
	var yy1 = y1.split(",");
	console.log(x1);
	console.log(y1);
	console.log(xx1);
	console.log(yy1);
	let driverChart2 = new Chart(myChart2,{
		type:'bar',// bar, horizontalBar, pie, line, doughnut, radar, polarArea
		data:{
			labels:yy1,
			datasets:[{
				label:'Driver Name',
				data:xx1,
				backgroundColor:['green','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD'],
				borderWidth:2,
				borderColor: 'grey',
				hoverBorderWidth:3,
				hoverBorderColor: 'grey',
			}]
		},
		options:{
			title:{
				display:true,
				text:'Driver Performances March ' + yearr,
				fontSize:20
			},
			legend:{
				position:'right', // top bottom left right
				labels:{
					fontColor:'#000'
				}
			},
			layout:{
				padding:{
					left:20,
					right:20,
					bottom:0,
					top:10
				}
			},
			tooltips:{
				enabled:true
			}
		}
	});
	</script>
	<script>
	let myChart3 = document.getElementById('myChart4').getContext('2d');
	Chart.defaults.global.defaultFontFamily='Calibri';
	Chart.defaults.global.defaultFontSize=15;
	Chart.defaults.global.defaultFontColor='green';
	
	var x1 = document.getElementById('data3').innerHTML;
	var y1 = document.getElementById('driver3').innerHTML;
	console.log(x1);
	var x1 = x1.slice(0,-1);
	var y1 = y1.slice(0,-1);
	var xx1 = x1.split(",");
	var yy1 = y1.split(",");
	console.log(x1);
	console.log(y1);
	console.log(xx1);
	console.log(yy1);
	let driverChart3 = new Chart(myChart3,{
		type:'bar',// bar, horizontalBar, pie, line, doughnut, radar, polarArea
		data:{
			labels:yy1,
			datasets:[{
				label:'Driver Name',
				data:xx1,
				backgroundColor:['green','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD'],
				borderWidth:2,
				borderColor: 'grey',
				hoverBorderWidth:3,
				hoverBorderColor: 'grey',
			}]
		},
		options:{
			title:{
				display:true,
				text:'Driver Performances  April ' + yearr,
				fontSize:20
			},
			legend:{
				position:'right', // top bottom left right
				labels:{
					fontColor:'#000'
				}
			},
			layout:{
				padding:{
					left:20,
					right:20,
					bottom:0,
					top:10
				}
			},
			tooltips:{
				enabled:true
			}
		}
	});
	</script>
	<script>
	let myChart4 = document.getElementById('myChart5').getContext('2d');
	Chart.defaults.global.defaultFontFamily='Calibri';
	Chart.defaults.global.defaultFontSize=15;
	Chart.defaults.global.defaultFontColor='green';
	
	var x1 = document.getElementById('data4').innerHTML;
	var y1 = document.getElementById('driver4').innerHTML;
	console.log(x1);
	var x1 = x1.slice(0,-1);
	var y1 = y1.slice(0,-1);
	var xx1 = x1.split(",");
	var yy1 = y1.split(",");
	console.log(x1);
	console.log(y1);
	console.log(xx1);
	console.log(yy1);
	let driverChart4 = new Chart(myChart4,{
		type:'bar',// bar, horizontalBar, pie, line, doughnut, radar, polarArea
		data:{
			labels:yy1,
			datasets:[{
				label:'Driver Name',
				data:xx1,
				backgroundColor:['green','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD'],
				borderWidth:2,
				borderColor: 'grey',
				hoverBorderWidth:3,
				hoverBorderColor: 'grey',
			}]
		},
		options:{
			title:{
				display:true,
				text:'Driver Performances  May ' + yearr,
				fontSize:20
			},
			legend:{
				position:'right', // top bottom left right
				labels:{
					fontColor:'#000'
				}
			},
			layout:{
				padding:{
					left:20,
					right:20,
					bottom:0,
					top:10
				}
			},
			tooltips:{
				enabled:true
			}
		}
	});
	</script>
	<script>
	let myChart5 = document.getElementById('myChart6').getContext('2d');
	Chart.defaults.global.defaultFontFamily='Calibri';
	Chart.defaults.global.defaultFontSize=15;
	Chart.defaults.global.defaultFontColor='green';
	
	var x1 = document.getElementById('data5').innerHTML;
	var y1 = document.getElementById('driver5').innerHTML;
	console.log(x1);
	var x1 = x1.slice(0,-1);
	var y1 = y1.slice(0,-1);
	var xx1 = x1.split(",");
	var yy1 = y1.split(",");
	console.log(x1);
	console.log(y1);
	console.log(xx1);
	console.log(yy1);
	let driverChart5 = new Chart(myChart5,{
		type:'bar',// bar, horizontalBar, pie, line, doughnut, radar, polarArea
		data:{
			labels:yy1,
			datasets:[{
				label:'Driver Name',
				data:xx1,
				backgroundColor:['green','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD'],
				borderWidth:2,
				borderColor: 'grey',
				hoverBorderWidth:3,
				hoverBorderColor: 'grey',
			}]
		},
		options:{
			title:{
				display:true,
				text:'Driver Performances  June ' + yearr,
				fontSize:20
			},
			legend:{
				position:'right', // top bottom left right
				labels:{
					fontColor:'#000'
				}
			},
			layout:{
				padding:{
					left:20,
					right:20,
					bottom:0,
					top:10
				}
			},
			tooltips:{
				enabled:true
			}
		}
	});
	</script>
	<script>
	let myChart6 = document.getElementById('myChart7').getContext('2d');
	Chart.defaults.global.defaultFontFamily='Calibri';
	Chart.defaults.global.defaultFontSize=15;
	Chart.defaults.global.defaultFontColor='green';
	
	var x1 = document.getElementById('data6').innerHTML;
	var y1 = document.getElementById('driver6').innerHTML;
	console.log(x1);
	var x1 = x1.slice(0,-1);
	var y1 = y1.slice(0,-1);
	var xx1 = x1.split(",");
	var yy1 = y1.split(",");
	console.log(x1);
	console.log(y1);
	console.log(xx1);
	console.log(yy1);
	let driverChart6 = new Chart(myChart6,{
		type:'bar',// bar, horizontalBar, pie, line, doughnut, radar, polarArea
		data:{
			labels:yy1,
			datasets:[{
				label:'Driver Name',
				data:xx1,
				backgroundColor:['green','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD'],
				borderWidth:2,
				borderColor: 'grey',
				hoverBorderWidth:3,
				hoverBorderColor: 'grey',
			}]
		},
		options:{
			title:{
				display:true,
				text:'Driver Performances  July ' + yearr,
				fontSize:20
			},
			legend:{
				position:'right', // top bottom left right
				labels:{
					fontColor:'#000'
				}
			},
			layout:{
				padding:{
					left:20,
					right:20,
					bottom:0,
					top:10
				}
			},
			tooltips:{
				enabled:true
			}
		}
	});
	</script>
	<script>
	let myChart7 = document.getElementById('myChart8').getContext('2d');
	Chart.defaults.global.defaultFontFamily='Calibri';
	Chart.defaults.global.defaultFontSize=15;
	Chart.defaults.global.defaultFontColor='green';
	
	var x1 = document.getElementById('data7').innerHTML;
	var y1 = document.getElementById('driver7').innerHTML;
	console.log(x1);
	var x1 = x1.slice(0,-1);
	var y1 = y1.slice(0,-1);
	var xx1 = x1.split(",");
	var yy1 = y1.split(",");
	console.log(x1);
	console.log(y1);
	console.log(xx1);
	console.log(yy1);
	let driverChart7 = new Chart(myChart7,{
		type:'bar',// bar, horizontalBar, pie, line, doughnut, radar, polarArea
		data:{
			labels:yy1,
			datasets:[{
				label:'Driver Name',
				data:xx1,
				backgroundColor:['green','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD'],
				borderWidth:2,
				borderColor: 'grey',
				hoverBorderWidth:3,
				hoverBorderColor: 'grey',
			}]
		},
		options:{
			title:{
				display:true,
				text:'Driver Performances  August ' + yearr,
				fontSize:20
			},
			legend:{
				position:'right', // top bottom left right
				labels:{
					fontColor:'#000'
				}
			},
			layout:{
				padding:{
					left:20,
					right:20,
					bottom:0,
					top:10
				}
			},
			tooltips:{
				enabled:true
			}
		}
	});
	</script>
	<script>
	let myChart8 = document.getElementById('myChart9').getContext('2d');
	Chart.defaults.global.defaultFontFamily='Calibri';
	Chart.defaults.global.defaultFontSize=15;
	Chart.defaults.global.defaultFontColor='green';
	
	var x1 = document.getElementById('data8').innerHTML;
	var y1 = document.getElementById('driver8').innerHTML;
	console.log(x1);
	var x1 = x1.slice(0,-1);
	var y1 = y1.slice(0,-1);
	var xx1 = x1.split(",");
	var yy1 = y1.split(",");
	console.log(x1);
	console.log(y1);
	console.log(xx1);
	console.log(yy1);
	let driverChart8 = new Chart(myChart8,{
		type:'bar',// bar, horizontalBar, pie, line, doughnut, radar, polarArea
		data:{
			labels:yy1,
			datasets:[{
				label:'Driver Name',
				data:xx1,
				backgroundColor:['green','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD'],
				borderWidth:2,
				borderColor: 'grey',
				hoverBorderWidth:3,
				hoverBorderColor: 'grey',
			}]
		},
		options:{
			title:{
				display:true,
				text:'Driver Performances  September ' + yearr,
				fontSize:20
			},
			legend:{
				position:'right', // top bottom left right
				labels:{
					fontColor:'#000'
				}
			},
			layout:{
				padding:{
					left:20,
					right:20,
					bottom:0,
					top:10
				}
			},
			tooltips:{
				enabled:true
			}
		}
	});
	</script>
	<script>
	let myChart9 = document.getElementById('myChart10').getContext('2d');
	Chart.defaults.global.defaultFontFamily='Calibri';
	Chart.defaults.global.defaultFontSize=15;
	Chart.defaults.global.defaultFontColor='green';
	
	var x1 = document.getElementById('data9').innerHTML;
	var y1 = document.getElementById('driver9').innerHTML;
	console.log(x1);
	var x1 = x1.slice(0,-1);
	var y1 = y1.slice(0,-1);
	var xx1 = x1.split(",");
	var yy1 = y1.split(",");
	console.log(x1);
	console.log(y1);
	console.log(xx1);
	console.log(yy1);
	let driverChart9 = new Chart(myChart9,{
		type:'bar',// bar, horizontalBar, pie, line, doughnut, radar, polarArea
		data:{
			labels:yy1,
			datasets:[{
				label:'Driver Name',
				data:xx1,
				backgroundColor:['green','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD'],
				borderWidth:2,
				borderColor: 'grey',
				hoverBorderWidth:3,
				hoverBorderColor: 'grey',
			}]
		},
		options:{
			title:{
				display:true,
				text:'Driver Performances  October ' + yearr,
				fontSize:20
			},
			legend:{
				position:'right', // top bottom left right
				labels:{
					fontColor:'#000'
				}
			},
			layout:{
				padding:{
					left:20,
					right:20,
					bottom:0,
					top:10
				}
			},
			tooltips:{
				enabled:true
			}
		}
	});
	</script>
	<script>
	let myChart10 = document.getElementById('myChart11').getContext('2d');
	Chart.defaults.global.defaultFontFamily='Calibri';
	Chart.defaults.global.defaultFontSize=15;
	Chart.defaults.global.defaultFontColor='green';
	
	var x1 = document.getElementById('data10').innerHTML;
	var y1 = document.getElementById('driver10').innerHTML;
	console.log(x1);
	var x1 = x1.slice(0,-1);
	var y1 = y1.slice(0,-1);
	var xx1 = x1.split(",");
	var yy1 = y1.split(",");
	console.log(x1);
	console.log(y1);
	console.log(xx1);
	console.log(yy1);
	let driverChart10 = new Chart(myChart10,{
		type:'bar',// bar, horizontalBar, pie, line, doughnut, radar, polarArea
		data:{
			labels:yy1,
			datasets:[{
				label:'Driver Name',
				data:xx1,
				backgroundColor:['green','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD'],
				borderWidth:2,
				borderColor: 'grey',
				hoverBorderWidth:3,
				hoverBorderColor: 'grey',
			}]
		},
		options:{
			title:{
				display:true,
				text:'Driver Performances  November ' + yearr,
				fontSize:20
			},
			legend:{
				position:'right', // top bottom left right
				labels:{
					fontColor:'#000'
				}
			},
			layout:{
				padding:{
					left:20,
					right:20,
					bottom:0,
					top:10
				}
			},
			tooltips:{
				enabled:true
			}
		}
	});
	</script>
	<script>
	let myChart11 = document.getElementById('myChart12').getContext('2d');
	Chart.defaults.global.defaultFontFamily='Calibri';
	Chart.defaults.global.defaultFontSize=15;
	Chart.defaults.global.defaultFontColor='green';
	
	var x1 = document.getElementById('data11').innerHTML;
	var y1 = document.getElementById('driver11').innerHTML;
	console.log(x1);
	var x1 = x1.slice(0,-1);
	var y1 = y1.slice(0,-1);
	var xx1 = x1.split(",");
	var yy1 = y1.split(",");
	console.log(x1);
	console.log(y1);
	console.log(xx1);
	console.log(yy1);
	let driverChart11 = new Chart(myChart11,{
		type:'bar',// bar, horizontalBar, pie, line, doughnut, radar, polarArea
		data:{
			labels:yy1,
			datasets:[{
				label:'Driver Name',
				data:xx1,
				backgroundColor:['green','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD','#CFF1CD'],
				borderWidth:2,
				borderColor: 'grey',
				hoverBorderWidth:3,
				hoverBorderColor: 'grey',
			}]
		},
		options:{
			title:{
				display:true,
				text:'Driver Performances  December ' + yearr,
				fontSize:20
			},
			legend:{
				position:'right', // top bottom left right
				labels:{
					fontColor:'#000'
				}
			},
			layout:{
				padding:{
					left:20,
					right:20,
					bottom:0,
					top:10
				}
			},
			tooltips:{
				enabled:true
			}
		}
	});
	</script>
	
	</div>
	</body>
</html>