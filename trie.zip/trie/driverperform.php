<?php
	session_start();
?>

<?php
	include_once 'connection.php';
	
?>

<!DOCTYPE html>
<html>
	<head>
    	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="mycss.css">
		<title>Driver performance</title>
	</head>
	<style>
	#submit_drip{
		margin-left:-116px;
	}
	</style>
	<header><?php include'navigation.php'?></header>
	
	<body>
	<?php if(isset($_SESSION['username'])){?>
	
	<?php include'driver_navi.php'?>
	
	<br/><br/><br/>
	
	<form action="driverperf.php" method="POST">
	<label for="dridate">
	Enter year for Monthly Performances of Drivers:
		<input type="text" name="dridate"/><br/><br/>
	</label>
	
	<input type='submit' id="submit_drip" value='Generate'>
	</form>
	<?php }
	else{
			echo 'Please <a href="login.php">Login</a>';
		}?>
	</body>
</html>