<?php

	session_start();
	
	$_SESSION['driverid']=$_POST['did'];
?>