<?php

	session_start();
	include_once 'connection.php';
	
?>

<!DOCTYPE html>
<html>
	<head>
    	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="mycss.css">
		<title>Map | View</title>
	</head>
	<header><?php include'navigation.php'?></header>
	
	<style>
	#submit_drip{
		margin-left:-116px;
	}
	</style>
	
	<body>
	

	<?php if(isset($_SESSION['username'])){?>
	<?php include 'holi_navi.php'?><br/><br/><br/>
	<form action="holiholi.php" method="POST">
	<label for="holiyear">
	Enter year for view and add holiday:
		<input type="text" name="holiyear"/><br/><br/>
	</label>
	
	<input type='submit' id="submit_drip" value='Generate'>
	</form>
	<form action="holiholiminus.php" method="POST">
	<label for="holiyear">
	Enter year for view and remove holiday:
		<input type="text" name="holiyear"/><br/><br/>
	</label>
	
	<input type='submit' id="submit_drip" value='Generate'>
	</form>
	<?php }
else{
			echo 'Please <a href="login.php">Login</a>';
		}?>
	</body>
</html>