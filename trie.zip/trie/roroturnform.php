<?php
session_start();
	include_once 'connection.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>Order Details</title>
<!--<link rel="stylesheet" href="style.css?vn={random number/string}">-->

    <link href="css/mycss.css" rel="stylesheet" type="text/css">
</head>
<header>
	<?php include'navigation.php'?>
</header>
<body>
<?php if(isset($_SESSION['username'])){?>
<?php include 'roro_navi.php'?>
<div style="margin-top:20px;">Enter Date To Generate Turns By Asset Form </div>
<form action = 'roroturn.php' method="POST">
<fieldset>
<legend> Daily Report</legend>
Start Date: <input type="date" name="sdate" value="<?php echo date('Y-m-d'); ?>" />
 Finish Date: <input type="date" name="fdate" value="<?php echo date('Y-m-d'); ?>" />
 
<br>
<input type='submit' value='Generate'>
</fieldset>
</form>
<?php }
else{
			echo 'Please <a href="login.php">Login</a>';
		}?> 

</body>
</html>