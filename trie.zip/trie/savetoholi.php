<?php
	include_once 'connection.php';
	if(isset($_POST['holidayss'])){
		$abc = $_POST['holidayss'];
		$holitoadd = explode(",",$abc);
		$x = 0;
		while($x<count($holitoadd)-1){
			$year = substr($holitoadd[$x],0,4);
			$month = substr($holitoadd[$x],4,2);
			$day =  substr($holitoadd[$x],6,2);
			$toadd = $year."-".$month."-".$day;
			$sss = "INSERT INTO holidaytable (holidayid, holidaydate) VALUES ('', '$toadd')";
			if ($conn->query($sss) === TRUE) {
				  echo "New record created successfully";
				} else {
				  echo "Error: " . $sss . "<br>" . $conn->error;
				}
			$x += 1;
		}
		header( "refresh:2;url=holiform.php" );
		
	}else{
		header("Location:holiform.php");
	}
	
?>