
<a href="trip.php" style="margin-right:10px">View Trip</a>
<a href="tripdone.php" style="margin-right:10px">View Trip DONE</a>
<a style="margin-right:10px;" href="uploadfile.php">Upload DHLS</a>

