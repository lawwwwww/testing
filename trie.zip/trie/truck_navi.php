<a href="truck.php" style="margin-right:10px">View Truck</a>
