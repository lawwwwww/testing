<?php

include_once 'connection.php';

$json = file_get_contents("php://input");
$obj = json_decode($json,true);

	date_default_timezone_set("Asia/Kuala_Lumpur");

	$date=date("Y-m-d");
	$time=date('H:i:s');

	
	$name=$obj['name'];
	$tid=$obj['tid'];
	
	$sqlsec="UPDATE triptable set return_date='".$date."',trip_status='Done',p_receive='".$name."',collection_time='".$time."' where tripID='".$tid."'";
	mysqli_query($conn,$sqlsec);
		
		$in="INSERT INTO tripdonetable(invoice_date,driverID,delivered,returned,tripID,p_receive,cust_name,areaID,container_retrieve,container_placed,collection_time,collection_type,waste_type,customer_sign,ship_date,return_date,image,instruction,truckID,salesOrderNo,address)(SELECT return_date,driverID,container_placed,container_retrieve,tripID,p_receive ,cust_name,areaID,container_retrieve,container_placed,collection_time,collection_type,waste_type,customer_sign,ship_date,return_date,image,instruction,truckID,salesOrderNo,address FROM triptable where tripID='".$tid."')";

		
		
if(mysqli_query($conn,$in))
	{
		$de="DELETE FROM triptable where tripID='".$tid."'";
		mysqli_query($conn,$de);
	}
		
?>